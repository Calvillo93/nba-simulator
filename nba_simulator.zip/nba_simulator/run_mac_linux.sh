#!/bin/bash

echo ""
echo "========================================"
echo "  NBA Private Simulator - Starting..."
echo "========================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed."
    echo "Install it with: brew install python   (Mac)"
    echo "or use your package manager on Linux."
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install / update requirements
echo "Installing dependencies (this may take a minute the first time)..."
pip install -r requirements.txt --quiet

# Run the app
echo ""
echo "Launching app... A browser window should open automatically."
echo "If it doesn't, go to: http://localhost:8501"
echo ""
echo "Keep this terminal open while using the simulator."
echo "Press Ctrl+C to stop the app."
echo ""
streamlit run app.py
