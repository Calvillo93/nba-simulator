# NBA Private Simulator

Personal Monte Carlo player projection tool built for private use.

## Features

- **10,000 Monte Carlo simulations** per player using recent form (weighted)
- Projections for:
  - Points (PTS)
  - Rebounds (REB)
  - Assists (AST)
  - PRA (PTS+REB+AST)
  - PR (PTS+REB)
  - PA (PTS+AST)
  - Triple-Double probability
- Full **player profiles** with official NBA headshots + team logos
- Recent game logs + interactive bar/line trend charts
- **Today’s live scoreboard**
- **Props Edge Checker** — paste any line from Underdog / PrizePicks / Kalshi and instantly see simulated over/under probability + distribution vs the line
- Dark, modern, mobile-friendly UI (Streamlit)

## Data Source

All live stats, game logs, and scoreboards come from the official NBA stats endpoints via the excellent open-source [`nba_api`](https://github.com/swar/nba_api) library.  
Headshots & logos are pulled directly from the NBA CDN.

## One-Click Launch

### Windows
1. Download the entire `nba_simulator` folder
2. Double-click **`run_windows.bat`**
3. The first time it will install everything automatically
4. A browser window will open with the simulator

### Mac / Linux
1. Download the entire `nba_simulator` folder
2. Double-click **`run_mac_linux.sh`**  
   (or open Terminal, `cd` into the folder, then run `./run_mac_linux.sh`)
3. The first time it will install everything automatically
4. A browser window will open with the simulator

---

### Manual way (if the scripts don’t work)

```bash
cd nba_simulator
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

The app opens at **http://localhost:8501**  
Works great on mobile too (open the same address on your phone while on the same Wi-Fi).

## How the Projection Model Works

1. Pulls the player’s last N regular-season games (default 12, adjustable 5–25).
2. Computes weighted mean & standard deviation (more recent games get higher weight).
3. Draws 10,000 independent samples from a truncated normal distribution for PTS / REB / AST.
4. Builds combo stats (PRA, PR, PA) by summing the independent draws.
5. Triple-double rate = % of simulations where PTS ≥ 10 **and** REB ≥ 10 **and** AST ≥ 10.

This is a strong baseline statistical model. It does **not** yet include:
- Opponent defensive ratings / matchup adjustments
- Minutes projections or injury news
- Pace or home/away splits
- Correlation between stats (beyond the simple sum)

You can improve accuracy later by layering those factors on top.

## Props Comparison

Underdog, PrizePicks, and Kalshi do not offer free public APIs for their player prop boards.  
The **Props Edge Checker** page is designed so you can quickly look up a line in the app of your choice, type it in, and immediately see what the 10k sims say the true probability is.

## Notes

- This tool is for **personal / private use only**.
- Always cross-check injuries, projected minutes, and matchup context.
- Not financial or gambling advice.

Enjoy the edges.  
Built with 🏀 and pure Python.
