@echo off
title NBA Private Simulator
echo.
echo ========================================
echo   NBA Private Simulator - Starting...
echo ========================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH.
    echo Download it from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

:: Create virtual environment if it doesn't exist
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

:: Activate virtual environment
call venv\Scripts\activate.bat

:: Install / update requirements
echo Installing dependencies (this may take a minute the first time)...
pip install -r requirements.txt --quiet

:: Run the app
echo.
echo Launching app... A browser window should open automatically.
echo If it doesn't, go to: http://localhost:8501
echo.
echo Keep this window open while using the simulator.
echo Press Ctrl+C to stop the app.
echo.
streamlit run app.py

pause
